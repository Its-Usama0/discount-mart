<?php
include 'inc/db.php';
session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:login.php');
}

if (isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];

    $select_order = mysqli_query($conn, "SELECT * FROM `orders` WHERE id = '$order_id'") or die('query failed');
    if (mysqli_num_rows($select_order) > 0) {
        $fetch_order = mysqli_fetch_assoc($select_order);
    } else {
        echo 'Order not found!';
        exit;
    }
} else {
    echo 'Invalid request!';
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Order</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css">
    <style>
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <div class="card shadow p-4">
                    <h2 class="text-center mb-4">Order Details</h2>
                    <table class="table">
                        <tbody>
                            <tr>
                                <th scope="col">User ID</th>
                                <td scope="row"><?php echo $fetch_order['user_id']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Placed On</th>
                                <td scope="row"><?php echo $fetch_order['placed_on']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Name</th>
                                <td scope="row"><?php echo $fetch_order['name']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Phone No.</th>
                                <td scope="row"><?php echo $fetch_order['number']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Email</th>
                                <td scope="row"><?php echo $fetch_order['email']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Address</th>
                                <td scope="row"><?php echo $fetch_order['address']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Total Products</th>
                                <td scope="row"><?php echo $fetch_order['total_products']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Total Price</th>
                                <td scope="row">Rs. <?php echo $fetch_order['total_price']; ?> /-</td>
                            </tr>
                            <tr>
                                <th scope="col">Payment Method</th>
                                <td scope="row"><?php echo $fetch_order['method']; ?></td>
                            </tr>
                            <tr>
                                <th scope="col">Payment Status</th>
                                <td scope="row"><?php echo $fetch_order['payment_status']; ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <button class="btn btn-primary no-print" onclick="window.print();">Print</button>
                    <a href="admin_orders.php" class="btn btn-secondary no-print">Back</a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
