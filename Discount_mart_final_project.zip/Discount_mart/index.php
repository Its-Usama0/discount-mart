<?php

include("inc/db.php");
if (isset($_POST['subscribe'])) {

    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $subscribe = mysqli_query($conn, "SELECT email FROM `subscriber` WHERE email = '$email'") or die('query failed');

    if (mysqli_num_rows($subscribe) > 0) {
        echo "<script>
                    alert('Email already exists!');
                  </script>";

    } else {
        $add_subscriber = mysqli_query($conn, "INSERT INTO `subscriber`(email) VALUES('$email')") or die('query failed');

        if ($add_subscriber) {
            echo "<script>
                    alert('Thanks for Subscribing Us!');
                  </script>";
        } else {
            echo "<script>
        alert('Something went wrong. Please try again!');
      </script>";
        }
    }
}
?>

<?php
include "inc/header.php";
?>

<style>
    .category:hover {
        background: #8e44ad;
        transition: all 0.5s;
        border-radius: 15px;
    }

    .icon {
        color: #8e44ad;
    }

    .category:hover .icon,
    .category:hover h5 {
        color: #fff;
    }

    .content {
        padding: 7rem 0;
    }

    h2 {
        font-size: 20px;
    }

    .bg-left-half {
        position: relative;
    }

    .bg-left-half:before {
        position: absolute;
        width: 50%;
        height: 100%;
        z-index: -1;
        content: "";
        left: 0;
        top: 0;
        background-color: #f8f9fa;
    }

    .media-29101 {
        padding: 10px;
    }

    .media-29101 img {
        margin-bottom: 10px;
    }

    .media-29101 h3 {
        font-size: 18px;
        font-weight: 900 !important;
    }

    .media-29101 h3 a {
        color: #6c757d;
    }

    .owl-2-style .owl-nav {
        display: none;
    }

    .owl-2-style .owl-dots {
        text-align: center;
        position: relative;
        bottom: -30px;
    }

    .owl-2-style .owl-dots .owl-dot {
        display: inline-block;
    }

    .owl-2-style .owl-dots .owl-dot span {
        display: inline-block;
        width: 15px;
        height: 3px;
        border-radius: 0px;
        background: #cccccc;
        -webkit-transition: 0.3s all cubic-bezier(0.32, 0.71, 0.53, 0.53);
        -o-transition: 0.3s all cubic-bezier(0.32, 0.71, 0.53, 0.53);
        transition: 0.3s all cubic-bezier(0.32, 0.71, 0.53, 0.53);
        margin: 3px;
    }

    .owl-2-style .owl-dots .owl-dot.active span {
        background: #007bff;
    }

    .owl-2-style .owl-dots .owl-dot:active,
    .owl-2-style .owl-dots .owl-dot:focus {
        outline: none;
    }

    .banner {
        background: url('images/banner-1.jpg');
        background-size: cover;
    }
    .banner_img{
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        width: 100%;
        height: 100vh;
    }
</style>

<!-- Carousel Start -->
<div class="container-fluid p-0 mb-4">
    <div class="owl-carousel header-carousel position-relative">

        <div class="owl-carousel-item position-relative">
            <img class="img-fluid" src="images/banner.jpg" alt="">
            <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center"
                style="background: rgba(24, 29, 56, .7);">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-sm-10 col-lg-8">

                            <h1 class="display-3 text-white animated slideInDown text-capitalize">Discount Mart For Budget Shopping</h1>
                            <p class=" text-white mb-4 pb-2">Its utility when the market price of goods decreases 
                    Our company DISCOUNT MART is the pioneer in providing complete services to the people.</p>
                            <a href="about.php"
                                class="btn text-white py-md-3 px-md-5 me-3 animated slideInLeft">Discover
                                More</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Carousel End -->




<!-- Items display Start -->

<div class="container-xxl py-5">
    <div class="site-section mb-5 ">
        <div class="container">

            <div class="row text-center">
                <div class="col-12">
                    <h6 class="section-title bg-white text-center px-3">Display Items</h6>
                    <h1 class="mb-4" style="color: #8e44ad;">You Can Discover More Item in Our Site</h1>
                </div>
            </div>


            <div class="container d-flex flex-wrap justify-content-between">

                <?php
                include("inc/db.php");
                $select_products = mysqli_query($conn, "SELECT * FROM `products`  order by rand() LIMIT 0,3 ") or die('query failed');
                if (mysqli_num_rows($select_products) > 0) {
                    while ($fetch_products = mysqli_fetch_assoc($select_products)) {
                        ?>
                         <div class=" col-md-3 mb-4">
                        <div class="media-29101 card h-100">
                            <a href="#">
                                <img src="uploaded_img/<?php echo $fetch_products['image']; ?>" class="img-fluid" alt="..."
                                    style="height:500px;">
                            </a>
                            <div class="cart-body">
                            <h3 class="card-title"><a href="" class="text-dark">
                                    <?php echo $fetch_products['name']; ?>
                                </a></h3>
                            <p>
                                <?php echo $fetch_products['author']; ?>
                            </p>
                            <div class="d-flex justify-content-between">
                                <small class="py-1 px-1 fw-bold fs-6 text-center">Rs.
                                    <?php echo $fetch_products['price']; ?>/-
                                </small>
                                <div>
                                    <a href="login.php" class="btn text-white">Add
                                        To Cart <i class="fa fa-chevron-right"></i></a>
                                </div>
                            </div>
                            </div>
                        </div>

                        </div>
                        <?php
                    }
                } else {
                    echo '<p class="empty">No products added yet!</p>';
                }
                ?>

            </div>

        </div>
    </div>
</div>

<!-- Items display End -->

<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 wow Up" data-wow-delay="0.1s" style="min-height: 400px;">
                <div class="position-relative h-100">
                    <img class="img-fluid position-absolute w-100 h-100" src="images/418723704_325059517165650_3098545478632040714_n.jpg" alt=""
                        style="object-fit: cover;">
                </div>
            </div>
            <div class="col-lg-6 wow Up" data-wow-delay="0.3s">
                <h6 class="section-title bg-white text-start pe-3">About Us</h6>
                <h1 class="mb-4" style="color: #8e44ad;">Why Choose Us</h1>
                <p class="mb-4">Discount Mart அதன் பரந்த அளவிலான உயர்தர தயாரிப்புகளுக்கு மலிவு விலையில் வழங்கப்படுகிறது. 
                    வசதியான ஆன்லைன் ஷாப்பிங் மற்றும் விரைவான டெலிவரி மூலம், தடையற்ற ஷாப்பிங் அனுபவத்தை நாங்கள் 
                    உறுதிசெய்கிறோம். சிறந்த வாடிக்கையாளர் சேவைக்கான எங்கள் அர்ப்பணிப்பு நீங்கள் நம்பிக்கையுடன் ஷாப்பிங் 
                    செய்யலாம் என்பதாகும். ஒவ்வொரு வாங்குதலிலும் சேமிக்க உதவும் வழக்கமான தள்ளுபடிகள், ஒப்பந்தங்கள் மற்றும் 
                    விளம்பரங்களை அனுபவிக்கவும். டிஸ்கவுண்ட் மார்ட்டில், மளிகைப் பொருட்களை வாங்குவதை எளிதாகவும், பட்ஜெட்டுக்கு 
                    ஏற்றதாகவும், எப்போதும் நம்பகமானதாகவும் ஆக்குகிறோம்.</p>


                <p class="mb-4">At Discount Mart, உங்களுக்கு சிறந்த ஷாப்பிங் அனுபவத்தை உறுதிசெய்ய எங்கள் அர்ப்பணிப்புள்ள குழு 
                    கடுமையாக உழைக்கிறது. எங்கள் பயனுள்ள வாடிக்கையாளர் சேவை பிரதிநிதிகள் முதல் திறமையான தளவாட குழு வரை, 
                    ஒவ்வொரு உறுப்பினரும் உயர்தர சேவையை வழங்குவதில் முக்கிய பங்கு வகிக்கின்றனர். நாங்கள் சிறந்து விளங்க 
                    உறுதிபூண்டுள்ளோம் மேலும் உங்கள் ஷாப்பிங் அனுபவத்தை வசதியாகவும் சுவாரஸ்யமாகவும் மாற்ற முயற்சிப்போம். 
                    தள்ளுபடி மார்ட்டைத் தேர்ந்தெடுத்ததற்கு நன்றி!

               </p>

                <a class="btn text-light py-3 px-5 mt-2" href="about.php">Read More</a>
            </div>
        </div>
    </div>
</div>
<!-- About End -->

<!-- Categories Start -->
<section class="py-5 py-md-11">
    <div class="container container-wd">
        <div class="text-center wow Up" data-wow-delay="0.1s">
            <h6 class="section-title text-center px-3" style="background: #fdfdfd;">Discovery more</h6>
            <h1 class="mb-5" style="color: #8e44ad;">Popular Items to Explore More</h1>
        </div>

        <div class="mx-n3"
            data-flickity='{"pageDots": true, "prevNextButtons": false, "cellAlign": "left", "wrapAround": true, "imagesLoaded": true}'>
            <?php
            include("inc/db.php");
            $select_category = mysqli_query($conn, "SELECT * FROM `category`") or die('query failed');
            if (mysqli_num_rows($select_category) > 0) {
                while ($fetch_category = mysqli_fetch_assoc($select_category)) {
                    ?>
                    <div class="col-12 col-md-4 mw-xl-20 mb-md-6 my-4 px-3 ">
                        <!-- Card -->
                        <a href="shop.php"
                            class="card shadow px-md-5 pt-md-9 pb-md-5 px-4 py-5 text-center lift position-relative h-100 category">

                            <!-- Image -->
                            <div class="display-4 mb-4 icon">
                                <?php echo $fetch_category["cat_icon"]; ?>
                            </div>

                            <!-- Footer -->
                            <div class="px-0 pb-0 pt-6">
                                <h5 class="mb-0 line-clamp-1">
                                    <?php echo $fetch_category['cat_name']; ?>
                                </h5>
                            </div>
                        </a>
                    </div>
                    <?php
                }
            } else {
                echo '<p class="empty">No categories added yet!</p>';
            }
            ?>
        </div>
    </div>
</section>
<!-- Categories End -->




<!-- Banner-1 Start -->
<div class="container-xxl py-5 pt-5 bg-light banner">
    <div class="container">
        <div class="row g-5 text-center">
            <div class="col-12 p-5 wow Up" data-wow-delay="0.3s">
                <h2 class="mb-2 text-white"><span style="color: #10c844;">Discount</span> Mart</h2>
                <h1 class="mb-2" style="color: #8e44ad;">SUPER SALES</h1>
                <h3 class="text-white">Discover Exciting Offers on Your Favorite Items</h3>
                <p class="mb-4" style="color: #d1d1d1;">பொருட்களின் சந்தை விலை குறைவடையும்போது அதன் பயனை 
                    முழுமையாக மக்களுக்கு வழங்குவதில் எமது DISCOUNT MART நிறுவனம் முதன்மையாளர்களாக திகழ்கிறது.</p>
                </p>
                <a class="btn text-light py-3 px-5 mt-2" href="login.php">Shop Now</a>
            </div>

        </div>
    </div>
</div>
<!-- Banner-1 End -->




<?php
include "inc/footer.php";
?>

<script>
    $(function () {

        if ($('.owl-2').length > 0) {
            $('.owl-2').owlCarousel({
                center: false,
                items: 1,
                loop: true,
                stagePadding: 0,
                margin: 20,
                smartSpeed: 1000,
                autoplay: true,
                nav: true,
                dots: true,
                pauseOnHover: false,
                responsive: {
                    600: {
                        margin: 20,
                        nav: true,
                        items: 2
                    },
                    1000: {
                        margin: 20,
                        stagePadding: 0,
                        nav: true,
                        items: 3
                    }
                }
            });
        }

    })
</script>