<nav class="navbar navbar-expand px-3 border-bottom bg-success">
      <button class="btn" id="sidebar-toggle" type="button">
         <span class="navbar-toggler-icon"></span>
      </button>
      <div class="navbar-collapse navbar">
         <ul class="navbar-nav">
            <li class="nav-item dropdown">
               <a href="home.php" class="btn btn-sm btn-primary px-2">
                  <i class="fa fa-home"></i> Go to Homepage
               </a>
            </li>
         </ul>
      </div>
   </nav>