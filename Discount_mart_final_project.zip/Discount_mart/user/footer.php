<footer class="footer">
    <div class="container-fluid bg-dark">
        <div class="row text-muted">
            <div class="col-12 text-center p-2">
                <p class="mb-0 text-white">
                HND IT final year project - <a class="border-bottom" href="">M.Usama</a>, 0758544879.
                </p>
            </div>

        </div>
    </div>
</footer>
