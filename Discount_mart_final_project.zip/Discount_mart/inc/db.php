<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "discount_mart";

$conn = new mysqli($server, $username, $password, $db);

?>