<?php
include 'inc/db.php';

session_start();

$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
    header('location:login.php');
}
?>
<?php
include "inc/header.php";
?>


<!-- Header Start -->
<div class="container-fluid bg-primary py-5 mb-5 page-header">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-10 text-center">
                <h1 class="display-3 text-white animated slideInDown">About Us</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center">
                        <li class="breadcrumb-item"><a class="text-white" href="home.php">Home</a></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- Header End -->

<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">

            <div class="col-lg-12 wow Up" data-wow-delay="0.3s">
                <h6 class="section-title bg-white text-start pe-3">About Us</h6>
                <h1 class="mb-4" style="color: #8e44ad;">Welcome to Discount Mart</h1>
                <p class="mb-4">
                    Welcome to Discount Mart, where the love for literature comes to life! Established in 2023, we are
                    more than just a Grocery store; we are a haven for bibliophiles and a community dedicated to the written
                    word.
                </p>

                <h3 class="mb-4">Our Mission</h3>
                <p class="mb-4">Your mission at Discount Mart’s online store is to save the most money while buying all 
                    the items on your grocery list. Start by making a detailed list and setting a budget. Before shopping
                    , check the website for deals, discounts, and digital coupons. Prioritize items on sale and compare 
                    prices of different brands and sizes. Stick to your list to avoid impulse buys. Maximize your savings
                     by using loyalty points and any available promo codes, aiming to save at least 20% off your total bill. 
                     After completing your order, share your savings success with the hashtag #DiscountMartMission. Happy saving!.</p>

                <h3 class="mb-4">Who We Are</h3>
                <p class="mb-4"> At Discount Mart, we provide quality products at unbeatable prices. As a leading online grocery store, 
                    we offer a wide range of items—from fresh produce and essentials to household goods and specialty products. 
                    Our mission is to make shopping easy, convenient, and budget-friendly, so you can focus on what matters most. 
                    With excellent customer service and great deals, Discount Mart is your go-to for all your grocery needs. 
                    Thank you for choosing us to help you save more and live better!.</p>

                <h3 class="mb-4">Our Collection</h3>

                <p class="mb-4">At Discount Mart, find everything you need—from fresh produce and pantry 
                    staples to household essentials and specialty items. Enjoy high-quality products at 
                    unbeatable prices, making us your one-stop shop for all your grocery needs.</p>

                <h3 class="mb-4">Why Choose Discount Mart?</h3>
               <p class="mb-4">
               Discount Mart stands out for its wide range of high-quality products offered at affordable 
               prices. With convenient online shopping and fast delivery, we ensure a seamless shopping 
               experience. Our commitment to excellent customer service means you can shop with confidence. 
               Enjoy regular discounts, deals, and promotions that help you save on every purchase. 
               At Discount Mart, we make grocery shopping easy, budget-friendly, and always reliable.
               </p>

                <h3 class="mb-4">Our Team</h3>

                <p class="mb-4">At Discount Mart, our dedicated team works hard to ensure you have the best 
                    shopping experience. From our helpful customer service representatives to our efficient 
                    logistics team, each member plays a vital role in providing high-quality service. We are 
                    committed to excellence and strive to make your shopping experience convenient and enjoyable. 
                    Thank you for choosing Discount Mart!.</p>

                <h3 class="mb-4">Contact Us</h3>

                <p class="mb-4">Have a question or just want to say hello? We'd love to hear from you! Reach out to us
                    through our <a href="contact.php">Contact Page</a>.</p>


                <p class=" mt-5 mb-4">Thank you for being a part of the Grocery store family. Happy reading!</p>

            </div>

        </div>
    </div>
</div>
<!-- About End -->


<?php
include "inc/footer.php";
?>